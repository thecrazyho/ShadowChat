import type { Express, Request, Response } from "express";
import { createServer, type Server } from "http";
import { Server as SocketIOServer } from "socket.io";
import passport from "passport";
import bcrypt from "bcrypt";
import multer from "multer";
import path from "path";
import { storage } from "./storage";
import { requireAuth } from "./auth";
import { insertUserSchema, insertMessageSchema } from "@shared/schema";

const upload = multer({
  dest: "uploads/",
  limits: {
    fileSize: 10 * 1024 * 1024, // 10MB limit
  },
});

const VALID_INVITE_CODES = ["SECURE2024", "ALPHA", "BETA", "GAMMA"];

export async function registerRoutes(app: Express): Promise<Server> {
  // Auth routes
  app.post("/api/auth/register", async (req: Request, res: Response) => {
    try {
      const { username, password, inviteCode } = req.body;

      if (!VALID_INVITE_CODES.includes(inviteCode)) {
        return res.status(400).json({ error: "Invalid invite code" });
      }

      const existingUser = await storage.getUserByUsername(username);
      if (existingUser) {
        return res.status(400).json({ error: "Username already exists" });
      }

      const hashedPassword = await bcrypt.hash(password, 10);
      const user = await storage.createUser({
        username,
        password: hashedPassword,
        inviteCode,
      });

      req.login(user, (err) => {
        if (err) {
          return res.status(500).json({ error: "Login failed after registration" });
        }
        const { password: _, ...userWithoutPassword } = user;
        res.json({ user: userWithoutPassword });
      });
    } catch (error: any) {
      console.error("Registration error:", error);
      res.status(500).json({ error: error.message });
    }
  });

  app.post("/api/auth/login", (req: Request, res: Response, next) => {
    passport.authenticate("local", (err: any, user: any, info: any) => {
      if (err) {
        return res.status(500).json({ error: err.message });
      }
      if (!user) {
        return res.status(401).json({ error: info?.message || "Authentication failed" });
      }
      req.login(user, (err) => {
        if (err) {
          return res.status(500).json({ error: "Login failed" });
        }
        const { password, ...userWithoutPassword } = user;
        res.json({ user: userWithoutPassword });
      });
    })(req, res, next);
  });

  app.post("/api/auth/logout", (req: Request, res: Response) => {
    const userId = (req.user as any)?.id;
    if (userId) {
      storage.updateUserStatus(userId, "offline").catch(console.error);
    }
    req.logout(() => {
      res.json({ success: true });
    });
  });

  app.get("/api/auth/me", requireAuth, (req: Request, res: Response) => {
    const user = req.user as any;
    const { password, ...userWithoutPassword } = user;
    res.json({ user: userWithoutPassword });
  });

  // User routes
  app.get("/api/users/search", requireAuth, async (req: Request, res: Response) => {
    try {
      const query = req.query.q as string;
      if (!query) {
        return res.json({ users: [] });
      }
      const users = await storage.searchUsers(query);
      const usersWithoutPasswords = users.map(({ password, ...user }) => user);
      res.json({ users: usersWithoutPasswords });
    } catch (error: any) {
      res.status(500).json({ error: error.message });
    }
  });

  // Conversation routes
  app.get("/api/conversations", requireAuth, async (req: Request, res: Response) => {
    try {
      const userId = (req.user as any).id;
      const conversations = await storage.getUserConversations(userId);
      res.json({ conversations });
    } catch (error: any) {
      res.status(500).json({ error: error.message });
    }
  });

  app.post("/api/conversations/private", requireAuth, async (req: Request, res: Response) => {
    try {
      const userId = (req.user as any).id;
      const { targetUserId } = req.body;

      if (!targetUserId) {
        return res.status(400).json({ error: "Target user ID is required" });
      }

      const targetUser = await storage.getUserById(targetUserId);
      if (!targetUser) {
        return res.status(404).json({ error: "User not found" });
      }

      const conversation = await storage.getOrCreatePrivateConversation(userId, targetUserId);
      res.json({ conversation });
    } catch (error: any) {
      res.status(500).json({ error: error.message });
    }
  });

  app.post("/api/conversations/group", requireAuth, async (req: Request, res: Response) => {
    try {
      const userId = (req.user as any).id;
      const { name, inviteCode } = req.body;

      if (!name || !inviteCode) {
        return res.status(400).json({ error: "Group name and invite code are required" });
      }

      const conversation = await storage.createConversation({
        isGroup: true,
        name,
        inviteCode,
        avatar: null,
      });

      await storage.addConversationMember(conversation.id, userId);
      res.json({ conversation });
    } catch (error: any) {
      res.status(500).json({ error: error.message });
    }
  });

  app.post("/api/conversations/join", requireAuth, async (req: Request, res: Response) => {
    try {
      const userId = (req.user as any).id;
      const { inviteCode } = req.body;

      if (!inviteCode) {
        return res.status(400).json({ error: "Invite code is required" });
      }

      const conversation = await storage.getConversationByInviteCode(inviteCode);
      if (!conversation) {
        return res.status(404).json({ error: "Group not found" });
      }

      await storage.addConversationMember(conversation.id, userId);
      res.json({ conversation });
    } catch (error: any) {
      res.status(500).json({ error: error.message });
    }
  });

  // Message routes
  app.get("/api/conversations/:id/messages", requireAuth, async (req: Request, res: Response) => {
    try {
      const conversationId = parseInt(req.params.id);
      const messages = await storage.getConversationMessages(conversationId);
      res.json({ messages });
    } catch (error: any) {
      res.status(500).json({ error: error.message });
    }
  });

  app.post("/api/conversations/:id/read", requireAuth, async (req: Request, res: Response) => {
    try {
      const userId = (req.user as any).id;
      const conversationId = parseInt(req.params.id);
      await storage.markMessagesAsRead(conversationId, userId);
      res.json({ success: true });
    } catch (error: any) {
      res.status(500).json({ error: error.message });
    }
  });

  // File upload route
  app.post("/api/upload", requireAuth, upload.single("file"), async (req: Request, res: Response) => {
    try {
      if (!req.file) {
        return res.status(400).json({ error: "No file uploaded" });
      }

      const fileUrl = `/uploads/${req.file.filename}`;
      const fileName = req.file.originalname;
      const fileType = req.file.mimetype;

      res.json({ fileUrl, fileName, fileType });
    } catch (error: any) {
      res.status(500).json({ error: error.message });
    }
  });

  // Serve uploaded files
  app.use("/uploads", requireAuth, (req, res, next) => {
    next();
  });

  const httpServer = createServer(app);
  const io = new SocketIOServer(httpServer, {
    cors: {
      origin: process.env.NODE_ENV === "production" ? false : ["http://localhost:5000"],
      credentials: true,
    },
  });

  // Socket.IO for real-time messaging
  const userSockets = new Map<number, string>();

  io.on("connection", (socket) => {
    console.log("User connected:", socket.id);

    socket.on("authenticate", async (userId: number) => {
      userSockets.set(userId, socket.id);
      await storage.updateUserStatus(userId, "online");
      io.emit("user:status", { userId, status: "online" });
    });

    socket.on("message:send", async (data) => {
      try {
        const { conversationId, senderId, content, fileUrl, fileName, fileType } = data;

        const message = await storage.createMessage({
          conversationId,
          senderId,
          content: content || "",
          fileUrl: fileUrl || null,
          fileName: fileName || null,
          fileType: fileType || null,
        });

        const fullMessage = {
          ...message,
          senderName: data.senderName,
          senderAvatar: data.senderAvatar,
        };

        io.emit(`conversation:${conversationId}:message`, fullMessage);
      } catch (error) {
        console.error("Error sending message:", error);
      }
    });

    socket.on("typing:start", (data) => {
      socket.to(`conversation:${data.conversationId}`).emit("typing:start", {
        userId: data.userId,
        username: data.username,
      });
    });

    socket.on("typing:stop", (data) => {
      socket.to(`conversation:${data.conversationId}`).emit("typing:stop", {
        userId: data.userId,
      });
    });

    socket.on("conversation:join", (conversationId) => {
      socket.join(`conversation:${conversationId}`);
    });

    socket.on("disconnect", async () => {
      console.log("User disconnected:", socket.id);
      for (const [userId, socketId] of Array.from(userSockets.entries())) {
        if (socketId === socket.id) {
          userSockets.delete(userId);
          await storage.updateUserStatus(userId, "offline");
          io.emit("user:status", { userId, status: "offline" });
          break;
        }
      }
    });
  });

  return httpServer;
}
