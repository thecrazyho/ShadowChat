import { eq, and, or, desc, sql, inArray } from "drizzle-orm";
import { drizzle } from "drizzle-orm/neon-serverless";
import { Pool } from "@neondatabase/serverless";
import * as schema from "@shared/schema";
import type { User, InsertUser, Conversation, Message, ConversationMember } from "@shared/schema";

const pool = new Pool({ connectionString: process.env.DATABASE_URL! });
const db = drizzle(pool, { schema });

export interface IStorage {
  // User methods
  getUserById(id: number): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  getUserByDisplayId(displayId: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  updateUserStatus(userId: number, status: string): Promise<void>;
  searchUsers(query: string): Promise<User[]>;
  
  // Conversation methods
  getConversationById(id: number): Promise<Conversation | undefined>;
  getConversationByInviteCode(inviteCode: string): Promise<Conversation | undefined>;
  getUserConversations(userId: number): Promise<any[]>;
  createConversation(conversation: Omit<Conversation, 'id' | 'createdAt'>): Promise<Conversation>;
  addConversationMember(conversationId: number, userId: number): Promise<void>;
  getOrCreatePrivateConversation(userId1: number, userId2: number): Promise<Conversation>;
  
  // Message methods
  getConversationMessages(conversationId: number, limit?: number): Promise<any[]>;
  createMessage(message: Omit<Message, 'id' | 'createdAt'>): Promise<Message>;
  markMessagesAsRead(conversationId: number, userId: number): Promise<void>;
  getUnreadCount(conversationId: number, userId: number): Promise<number>;
}

export class DatabaseStorage implements IStorage {
  async getUserById(id: number): Promise<User | undefined> {
    const result = await db.select().from(schema.users).where(eq(schema.users.id, id)).limit(1);
    return result[0];
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    const result = await db.select().from(schema.users).where(eq(schema.users.username, username)).limit(1);
    return result[0];
  }

  async getUserByDisplayId(displayId: string): Promise<User | undefined> {
    const result = await db.select().from(schema.users).where(eq(schema.users.displayId, displayId)).limit(1);
    return result[0];
  }

  async createUser(user: InsertUser): Promise<User> {
    const maxId = await db.select({ max: sql<number>`COALESCE(MAX(id), 0)` }).from(schema.users);
    const nextId = (maxId[0]?.max || 0) + 1;
    const displayId = String(nextId).padStart(4, '0');
    
    const result = await db.insert(schema.users).values({
      ...user,
      displayId,
      status: 'online',
    }).returning();
    
    return result[0];
  }

  async updateUserStatus(userId: number, status: string): Promise<void> {
    await db.update(schema.users)
      .set({ status, lastSeen: new Date() })
      .where(eq(schema.users.id, userId));
  }

  async searchUsers(query: string): Promise<User[]> {
    return db.select().from(schema.users)
      .where(
        or(
          sql`${schema.users.username} ILIKE ${`%${query}%`}`,
          sql`${schema.users.displayId} LIKE ${`%${query}%`}`
        )
      )
      .limit(20);
  }

  async getConversationById(id: number): Promise<Conversation | undefined> {
    const result = await db.select().from(schema.conversations)
      .where(eq(schema.conversations.id, id))
      .limit(1);
    return result[0];
  }

  async getConversationByInviteCode(inviteCode: string): Promise<Conversation | undefined> {
    const result = await db.select().from(schema.conversations)
      .where(eq(schema.conversations.inviteCode, inviteCode))
      .limit(1);
    return result[0];
  }

  async getUserConversations(userId: number): Promise<any[]> {
    const conversations = await db
      .select({
        conversation: schema.conversations,
        lastMessage: sql<string>`(
          SELECT content FROM ${schema.messages} 
          WHERE conversation_id = ${schema.conversations.id}
          ORDER BY created_at DESC LIMIT 1
        )`,
        lastMessageTime: sql<Date>`(
          SELECT created_at FROM ${schema.messages}
          WHERE conversation_id = ${schema.conversations.id}
          ORDER BY created_at DESC LIMIT 1
        )`,
        unreadCount: sql<number>`(
          SELECT COUNT(*) FROM ${schema.messages} m
          WHERE m.conversation_id = ${schema.conversations.id}
          AND m.created_at > (
            SELECT COALESCE(last_read, '1970-01-01'::timestamp)
            FROM ${schema.conversationMembers}
            WHERE conversation_id = ${schema.conversations.id}
            AND user_id = ${userId}
          )
          AND m.sender_id != ${userId}
        )`,
      })
      .from(schema.conversations)
      .innerJoin(
        schema.conversationMembers,
        eq(schema.conversations.id, schema.conversationMembers.conversationId)
      )
      .where(eq(schema.conversationMembers.userId, userId))
      .orderBy(desc(sql`last_message_time`));

    // Get other participant info for private chats
    const conversationsWithDetails = await Promise.all(
      conversations.map(async (conv) => {
        if (!conv.conversation.isGroup) {
          const members = await db.select({ user: schema.users })
            .from(schema.conversationMembers)
            .innerJoin(schema.users, eq(schema.conversationMembers.userId, schema.users.id))
            .where(
              and(
                eq(schema.conversationMembers.conversationId, conv.conversation.id),
                sql`${schema.users.id} != ${userId}`
              )
            )
            .limit(1);

          const otherUser = members[0]?.user;
          return {
            ...conv.conversation,
            name: otherUser?.username || 'Unknown User',
            avatar: otherUser?.avatar,
            userId: otherUser?.displayId,
            status: otherUser?.status,
            lastMessage: conv.lastMessage,
            lastMessageTime: conv.lastMessageTime,
            unreadCount: Number(conv.unreadCount),
          };
        }

        const memberCount = await db.select({ count: sql<number>`count(*)` })
          .from(schema.conversationMembers)
          .where(eq(schema.conversationMembers.conversationId, conv.conversation.id));

        return {
          ...conv.conversation,
          memberCount: Number(memberCount[0]?.count || 0),
          lastMessage: conv.lastMessage,
          lastMessageTime: conv.lastMessageTime,
          unreadCount: Number(conv.unreadCount),
        };
      })
    );

    return conversationsWithDetails;
  }

  async createConversation(conversation: Omit<Conversation, 'id' | 'createdAt'>): Promise<Conversation> {
    const result = await db.insert(schema.conversations).values(conversation).returning();
    return result[0];
  }

  async addConversationMember(conversationId: number, userId: number): Promise<void> {
    await db.insert(schema.conversationMembers).values({
      conversationId,
      userId,
    });
  }

  async getOrCreatePrivateConversation(userId1: number, userId2: number): Promise<Conversation> {
    const existing = await db
      .select({ conversation: schema.conversations })
      .from(schema.conversations)
      .innerJoin(
        schema.conversationMembers,
        eq(schema.conversations.id, schema.conversationMembers.conversationId)
      )
      .where(
        and(
          eq(schema.conversations.isGroup, false),
          eq(schema.conversationMembers.userId, userId1),
          sql`EXISTS (
            SELECT 1 FROM ${schema.conversationMembers} cm2
            WHERE cm2.conversation_id = ${schema.conversations.id}
            AND cm2.user_id = ${userId2}
          )`
        )
      )
      .limit(1);

    if (existing.length > 0) {
      return existing[0].conversation;
    }

    const newConversation = await this.createConversation({
      isGroup: false,
      name: null,
      avatar: null,
      inviteCode: null,
    });

    await this.addConversationMember(newConversation.id, userId1);
    await this.addConversationMember(newConversation.id, userId2);

    return newConversation;
  }

  async getConversationMessages(conversationId: number, limit: number = 50): Promise<any[]> {
    const messages = await db
      .select({
        message: schema.messages,
        sender: schema.users,
      })
      .from(schema.messages)
      .innerJoin(schema.users, eq(schema.messages.senderId, schema.users.id))
      .where(eq(schema.messages.conversationId, conversationId))
      .orderBy(desc(schema.messages.createdAt))
      .limit(limit);

    return messages.map((m) => ({
      ...m.message,
      senderName: m.sender.username,
      senderAvatar: m.sender.avatar,
      senderDisplayId: m.sender.displayId,
    })).reverse();
  }

  async createMessage(message: Omit<Message, 'id' | 'createdAt'>): Promise<Message> {
    const result = await db.insert(schema.messages).values(message).returning();
    return result[0];
  }

  async markMessagesAsRead(conversationId: number, userId: number): Promise<void> {
    await db.update(schema.conversationMembers)
      .set({ lastRead: new Date() })
      .where(
        and(
          eq(schema.conversationMembers.conversationId, conversationId),
          eq(schema.conversationMembers.userId, userId)
        )
      );
  }

  async getUnreadCount(conversationId: number, userId: number): Promise<number> {
    const result = await db
      .select({ count: sql<number>`count(*)` })
      .from(schema.messages)
      .where(
        and(
          eq(schema.messages.conversationId, conversationId),
          sql`${schema.messages.createdAt} > (
            SELECT COALESCE(last_read, '1970-01-01'::timestamp)
            FROM ${schema.conversationMembers}
            WHERE conversation_id = ${conversationId}
            AND user_id = ${userId}
          )`,
          sql`${schema.messages.senderId} != ${userId}`
        )
      );

    return Number(result[0]?.count || 0);
  }
}

export const storage = new DatabaseStorage();
