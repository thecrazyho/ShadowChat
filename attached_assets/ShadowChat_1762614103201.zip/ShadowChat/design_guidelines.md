# Design Guidelines: Dark-Themed Messaging Web App

## Design Approach

**Selected Approach:** Reference-Based (Messaging Apps)  
**Primary References:** Discord, Telegram Dark Mode, Signal  
**Aesthetic Direction:** Stealthy, minimalist, "under the radar" with neon accents

**Core Design Principles:**
- Information density without clutter
- Instant visual hierarchy for message threads
- Privacy-focused, low-profile aesthetic
- Zero distractions from communication

## Color Treatment (Per User Requirements)

- **Backgrounds:** Pure black (#000000) for main areas, dark gray (#1a1a1a to #2a2a2a) for panels/cards
- **Accents:** Neon blue (#00d9ff) or purple (#a855f7) for interactive elements, status indicators, and highlights
- **Text:** White/light gray hierarchy for readability on dark backgrounds

## Typography System

**Font Stack:** Inter or system fonts (-apple-system, BlinkMacSystemFont, "Segoe UI")

**Hierarchy:**
- **Chat messages:** text-sm (14px), medium weight for sender names, regular for message content
- **Timestamps/metadata:** text-xs (12px), muted treatment
- **Navigation/headers:** text-base to text-lg, semibold
- **Input fields:** text-sm, consistent with message display
- **User IDs/codes:** Monospace font (font-mono) for technical identifiers

## Layout System

**Spacing Primitives:** Tailwind units of 2, 4, 6, and 8 (p-2, m-4, gap-6, h-8)

**Core Layout Structure:**

**Desktop (3-column):**
1. **Left Sidebar (280px):** User profile, conversation list, new chat button
2. **Center Panel (flexible):** Active chat messages and input
3. **Right Sidebar (300px, collapsible):** Chat details, members, media gallery

**Mobile (single column):** Stack with bottom navigation, slide-in panels for chat list

**Message Layout:**
- Outgoing messages: right-aligned, accent-colored bubble
- Incoming messages: left-aligned, dark gray bubble
- Consistent padding: p-3 for message bubbles, gap-2 between messages
- Avatar size: 8x8 for chat list, 10x10 for message threads
- Timestamp positioning: outside bubble, text-xs, subtle

## Component Library

**Navigation Components:**
- Top bar: h-14, flex items-center, px-4, border-b with subtle divider
- Conversation list items: h-16, hover state with slight background lift
- Active conversation: border-left accent indicator (4px wide)

**Chat Components:**
- Message bubbles: rounded-2xl for smooth aesthetic, max-w-md to prevent over-width
- Input box: fixed bottom, backdrop-blur effect, h-14 minimum
- Attachment buttons: icon-only, hover reveals labels
- Group chat avatars: overlapping circles for member count visualization

**Form Elements (Login/Registration):**
- Input fields: h-12, rounded-lg, dark gray background with subtle border
- Buttons: h-12, rounded-lg, full neon accent for primary actions
- Invite code input: monospace font, letter-spacing for clarity
- Error states: subtle red accent, inline with field

**Group Chat Specific:**
- Group header: larger (h-20), displays group image, name, member count
- Member list: compact grid (2-3 columns), with role badges if applicable
- Group code display: copy-to-clipboard with confirmation feedback

**Status Indicators:**
- Online/offline dots: w-3 h-3, positioned absolute on avatars
- Message seen status: dual checkmarks, accent color when read
- Typing indicators: animated ellipsis, subtle pulse

## Icons

**Library:** Heroicons (via CDN)  
**Usage:** Consistent 20px icons for buttons, 16px for inline elements

**Key Icons:**
- Send: paper airplane
- Attach: paperclip
- Image upload: photo
- Group: users/user-group
- Search: magnifying glass
- Settings: cog

## Responsive Behavior

**Breakpoints:**
- Mobile: < 768px (single column, bottom nav)
- Tablet: 768px - 1024px (2-column, hide right sidebar by default)
- Desktop: > 1024px (full 3-column layout)

**Mobile Optimizations:**
- Full-width message bubbles with reduced max-width (max-w-[85%])
- Floating action button for new chat (bottom-right)
- Swipe gestures for navigation between views
- Larger tap targets: min h-12 for all interactive elements

## Interaction Patterns

**Transitions:** Smooth and fast (150-200ms) for panel slides, minimal animation elsewhere  
**Focus States:** Neon accent outline (2px) on interactive elements  
**Loading States:** Skeleton screens with dark gray shimmer for message history

**Key User Flows:**
1. **Login:** Centered card, max-w-md, minimal fields, clear validation feedback
2. **Chat Search:** Top-positioned search bar, instant filter results below
3. **Message Sending:** Auto-focus input, Enter to send, Shift+Enter for new line
4. **File Upload:** Drag-and-drop zone overlay, preview before sending

## Data Display Patterns

- **Unique IDs:** Display as badges (bg-dark-gray, neon text, font-mono, rounded-full px-3)
- **Timestamps:** Relative time (e.g., "2m ago"), full time on hover
- **File Attachments:** Preview thumbnails for images, icon + filename for documents
- **Unread Count:** Neon accent badge, positioned top-right on conversation items

This design creates a cohesive, focused messaging experience that feels secure and minimal while maintaining excellent usability across devices.