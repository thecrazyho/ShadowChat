async function apiCall<T>(url: string, options?: RequestInit): Promise<T> {
  const res = await fetch(url, {
    credentials: "include",
    headers: {
      "Content-Type": "application/json",
      ...options?.headers,
    },
    ...options,
  });

  if (!res.ok) {
    const text = await res.text();
    throw new Error(text || res.statusText);
  }

  return res.json();
}

export interface User {
  id: number;
  username: string;
  displayId: string;
  avatar?: string;
  status: string;
  inviteCode: string;
}

export interface Conversation {
  id: number;
  name?: string;
  avatar?: string;
  isGroup: boolean;
  inviteCode?: string;
  lastMessage?: string;
  lastMessageTime?: Date;
  unreadCount?: number;
  userId?: string;
  status?: string;
  memberCount?: number;
}

export interface Message {
  id: number;
  conversationId: number;
  senderId: number;
  content: string;
  fileUrl?: string;
  fileName?: string;
  fileType?: string;
  createdAt: Date;
  senderName?: string;
  senderAvatar?: string;
  senderDisplayId?: string;
}

export const authApi = {
  register: async (username: string, password: string, inviteCode: string) => {
    return apiCall<{ user: User }>("/api/auth/register", {
      method: "POST",
      body: JSON.stringify({ username, password, inviteCode }),
    });
  },

  login: async (username: string, password: string, inviteCode: string) => {
    return apiCall<{ user: User }>("/api/auth/login", {
      method: "POST",
      body: JSON.stringify({ username, password, inviteCode }),
    });
  },

  logout: async () => {
    return apiCall<{ success: boolean }>("/api/auth/logout", {
      method: "POST",
    });
  },

  getMe: async () => {
    return apiCall<{ user: User }>("/api/auth/me");
  },
};

export const userApi = {
  search: async (query: string) => {
    return apiCall<{ users: User[] }>(`/api/users/search?q=${encodeURIComponent(query)}`);
  },
};

export const conversationApi = {
  getAll: async () => {
    return apiCall<{ conversations: Conversation[] }>("/api/conversations");
  },

  createPrivate: async (targetUserId: number) => {
    return apiCall<{ conversation: Conversation }>("/api/conversations/private", {
      method: "POST",
      body: JSON.stringify({ targetUserId }),
    });
  },

  createGroup: async (name: string, inviteCode: string) => {
    return apiCall<{ conversation: Conversation }>("/api/conversations/group", {
      method: "POST",
      body: JSON.stringify({ name, inviteCode }),
    });
  },

  joinGroup: async (inviteCode: string) => {
    return apiCall<{ conversation: Conversation }>("/api/conversations/join", {
      method: "POST",
      body: JSON.stringify({ inviteCode }),
    });
  },
};

export const messageApi = {
  getMessages: async (conversationId: number) => {
    return apiCall<{ messages: Message[] }>(`/api/conversations/${conversationId}/messages`);
  },

  markAsRead: async (conversationId: number) => {
    return apiCall<{ success: boolean }>(`/api/conversations/${conversationId}/read`, {
      method: "POST",
    });
  },
};

export const uploadApi = {
  uploadFile: async (file: File) => {
    const formData = new FormData();
    formData.append("file", file);

    const response = await fetch("/api/upload", {
      method: "POST",
      body: formData,
      credentials: "include",
    });

    if (!response.ok) {
      throw new Error("Upload failed");
    }

    return response.json() as Promise<{ fileUrl: string; fileName: string; fileType: string }>;
  },
};
