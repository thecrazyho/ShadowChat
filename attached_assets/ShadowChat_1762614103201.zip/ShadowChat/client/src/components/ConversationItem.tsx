import { cn } from "@/lib/utils";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Badge } from "@/components/ui/badge";
import OnlineStatus from "./OnlineStatus";
import { formatDistanceToNow } from "date-fns";

type Status = "online" | "away" | "busy" | "offline";

interface ConversationItemProps {
  id: string;
  name: string;
  avatar?: string;
  lastMessage: string;
  timestamp: Date;
  unreadCount?: number;
  isActive?: boolean;
  isGroup?: boolean;
  status?: Status;
  onClick?: () => void;
}

export default function ConversationItem({
  id,
  name,
  avatar,
  lastMessage,
  timestamp,
  unreadCount = 0,
  isActive = false,
  isGroup = false,
  status = "offline",
  onClick,
}: ConversationItemProps) {
  return (
    <div
      data-testid={`conversation-item-${id}`}
      onClick={onClick}
      className={cn(
        "flex items-center gap-3 p-3 rounded-lg cursor-pointer transition-colors hover-elevate active-elevate-2",
        isActive && "bg-sidebar-accent"
      )}
    >
      <div className="relative shrink-0">
        <Avatar className="w-12 h-12">
          <AvatarImage src={avatar} alt={name} />
          <AvatarFallback className="bg-card text-sm">
            {name.charAt(0).toUpperCase()}
          </AvatarFallback>
        </Avatar>
        {!isGroup && <OnlineStatus status={status} className="absolute -bottom-0.5 -right-0.5" />}
      </div>

      <div className="flex-1 min-w-0">
        <div className="flex items-center justify-between gap-2 mb-1">
          <h3 className="font-medium text-sm truncate">{name}</h3>
          <span className="text-xs text-muted-foreground shrink-0">
            {formatDistanceToNow(timestamp, { addSuffix: false })}
          </span>
        </div>
        <p className="text-sm text-muted-foreground truncate">{lastMessage}</p>
      </div>

      {unreadCount > 0 && (
        <Badge
          data-testid={`badge-unread-${id}`}
          variant="default"
          className="shrink-0 min-w-[1.25rem] h-5 flex items-center justify-center px-1.5"
        >
          {unreadCount > 99 ? "99+" : unreadCount}
        </Badge>
      )}
    </div>
  );
}
