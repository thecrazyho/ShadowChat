import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Badge } from "@/components/ui/badge";
import { Search, X } from "lucide-react";
import { cn } from "@/lib/utils";
import { userApi } from "@/lib/api";
import type { User } from "@/lib/api";

interface UserSearchProps {
  onSelectUser?: (user: User) => void;
  onClose?: () => void;
}

export default function UserSearch({ onSelectUser, onClose }: UserSearchProps) {
  const [searchQuery, setSearchQuery] = useState("");

  const { data, isLoading } = useQuery({
    queryKey: ["/api/users/search", searchQuery],
    queryFn: () => userApi.search(searchQuery),
    enabled: searchQuery.length > 0,
  });

  const users = data?.users || [];

  return (
    <div className="flex flex-col h-full bg-card">
      <div className="flex items-center gap-3 p-4 border-b border-border">
        <div className="relative flex-1">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
          <Input
            data-testid="input-search-users"
            type="text"
            placeholder="Search by username or ID..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="pl-10"
            autoFocus
          />
        </div>
        <Button
          size="icon"
          variant="ghost"
          data-testid="button-close-search"
          onClick={onClose}
        >
          <X className="h-5 w-5" />
        </Button>
      </div>

      <div className="flex-1 overflow-y-auto p-2">
        {isLoading ? (
          <div className="text-center py-12 text-muted-foreground">
            Searching...
          </div>
        ) : users.length === 0 ? (
          <div className="text-center py-12 text-muted-foreground">
            {searchQuery ? "No users found" : "Start typing to search for users"}
          </div>
        ) : (
          <div className="space-y-1">
            {users.map((user) => (
              <div
                key={user.id}
                data-testid={`user-result-${user.id}`}
                onClick={() => {
                  console.log("Selected user:", user);
                  onSelectUser?.(user);
                }}
                className="flex items-center gap-3 p-3 rounded-lg cursor-pointer hover-elevate active-elevate-2"
              >
                <Avatar className="w-10 h-10 shrink-0">
                  <AvatarImage src={user.avatar} alt={user.username} />
                  <AvatarFallback className="bg-muted">
                    {user.username.charAt(0).toUpperCase()}
                  </AvatarFallback>
                </Avatar>

                <div className="flex-1 min-w-0">
                  <h3 className="font-medium text-sm truncate">{user.username}</h3>
                  <Badge
                    variant="secondary"
                    className="font-mono text-xs px-2 py-0 mt-1"
                  >
                    #{user.displayId}
                  </Badge>
                </div>

                <div
                  className={cn(
                    "w-2 h-2 rounded-full shrink-0",
                    user.status === "online" && "bg-green-500",
                    user.status === "away" && "bg-yellow-500",
                    user.status === "busy" && "bg-red-500",
                    user.status === "offline" && "bg-muted-foreground"
                  )}
                />
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}
