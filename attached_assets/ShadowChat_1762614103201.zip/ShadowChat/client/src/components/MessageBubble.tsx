import { cn } from "@/lib/utils";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Check, CheckCheck } from "lucide-react";
import { formatDistanceToNow } from "date-fns";

interface MessageBubbleProps {
  message: string;
  timestamp: Date;
  isOwn: boolean;
  senderName?: string;
  senderAvatar?: string;
  isRead?: boolean;
  imageUrl?: string;
  fileUrl?: string;
  fileName?: string;
}

export default function MessageBubble({
  message,
  timestamp,
  isOwn,
  senderName,
  senderAvatar,
  isRead = false,
  imageUrl,
  fileUrl,
  fileName,
}: MessageBubbleProps) {
  return (
    <div className={cn("flex gap-2 group", isOwn ? "flex-row-reverse" : "flex-row")}>
      {!isOwn && (
        <Avatar className="w-8 h-8 shrink-0">
          <AvatarImage src={senderAvatar} alt={senderName} />
          <AvatarFallback className="text-xs bg-card">
            {senderName?.charAt(0).toUpperCase()}
          </AvatarFallback>
        </Avatar>
      )}

      <div className={cn("flex flex-col gap-1 max-w-[85%] md:max-w-md", isOwn && "items-end")}>
        {!isOwn && senderName && (
          <span className="text-xs text-muted-foreground px-3">{senderName}</span>
        )}

        <div
          className={cn(
            "px-4 py-2.5 rounded-2xl break-words",
            isOwn
              ? "bg-primary text-primary-foreground"
              : "bg-card text-card-foreground"
          )}
        >
          {imageUrl && (
            <img
              src={imageUrl}
              alt="Shared image"
              className="rounded-lg mb-2 max-w-full h-auto"
            />
          )}

          {fileUrl && fileName && (
            <a
              href={fileUrl}
              data-testid={`link-file-${fileName}`}
              download={fileName}
              className="flex items-center gap-2 mb-2 hover-elevate px-2 py-1 rounded bg-background/10"
            >
              <span className="text-sm font-mono truncate">{fileName}</span>
            </a>
          )}

          <p className="text-sm whitespace-pre-wrap">{message}</p>
        </div>

        <div className={cn("flex items-center gap-1 px-3", isOwn && "flex-row-reverse")}>
          <span className="text-xs text-muted-foreground">
            {formatDistanceToNow(timestamp, { addSuffix: true })}
          </span>
          {isOwn && (
            <div className="text-muted-foreground">
              {isRead ? (
                <CheckCheck className="w-3 h-3 text-primary" data-testid="icon-read" />
              ) : (
                <Check className="w-3 h-3" data-testid="icon-sent" />
              )}
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
