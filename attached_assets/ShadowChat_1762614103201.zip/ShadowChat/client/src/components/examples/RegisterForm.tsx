import RegisterForm from '../RegisterForm';

export default function RegisterFormExample() {
  return (
    <div className="flex items-center justify-center min-h-screen bg-background p-4">
      <RegisterForm
        onRegister={(username, password, inviteCode) => console.log('Register:', { username, inviteCode })}
        onSwitchToLogin={() => console.log('Switch to login')}
      />
    </div>
  );
}
