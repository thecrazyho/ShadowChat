import LoginForm from '../LoginForm';

export default function LoginFormExample() {
  return (
    <div className="flex items-center justify-center min-h-screen bg-background p-4">
      <LoginForm
        onLogin={(username, password, inviteCode) => console.log('Login:', { username, inviteCode })}
        onSwitchToRegister={() => console.log('Switch to register')}
      />
    </div>
  );
}
