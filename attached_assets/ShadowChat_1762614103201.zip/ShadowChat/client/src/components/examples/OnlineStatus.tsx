import OnlineStatus from '../OnlineStatus';

export default function OnlineStatusExample() {
  return (
    <div className="flex flex-col gap-4 p-8 bg-background">
      <OnlineStatus status="online" showLabel />
      <OnlineStatus status="away" showLabel />
      <OnlineStatus status="busy" showLabel />
      <OnlineStatus status="offline" showLabel />
    </div>
  );
}
