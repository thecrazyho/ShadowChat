import { useState } from 'react';
import GroupCreationModal from '../GroupCreationModal';
import { Button } from '@/components/ui/button';

export default function GroupCreationModalExample() {
  const [isOpen, setIsOpen] = useState(false);

  return (
    <div className="flex items-center justify-center min-h-screen bg-background p-4">
      <Button onClick={() => setIsOpen(true)} data-testid="button-open-modal">
        Open Group Creation
      </Button>
      <GroupCreationModal
        isOpen={isOpen}
        onClose={() => setIsOpen(false)}
        onCreate={(name, image) => console.log('Created:', name, image?.name)}
      />
    </div>
  );
}
