import ChatInput from '../ChatInput';

export default function ChatInputExample() {
  return (
    <div className="bg-background max-w-2xl">
      <ChatInput
        onSendMessage={(message, files) => console.log('Send:', message, 'Files:', files?.length)}
        placeholder="Type a message..."
      />
    </div>
  );
}
