import MessageBubble from '../MessageBubble';
import avatar1 from '@assets/generated_images/Neon_gradient_avatar_1_a8a998c7.png';

export default function MessageBubbleExample() {
  return (
    <div className="flex flex-col gap-4 p-8 bg-background max-w-2xl">
      <MessageBubble
        message="Hey! How are you doing?"
        timestamp={new Date(Date.now() - 1000 * 60 * 5)}
        isOwn={false}
        senderName="Alex"
        senderAvatar={avatar1}
        isRead={false}
      />
      <MessageBubble
        message="I'm great! Just working on this new project. What about you?"
        timestamp={new Date(Date.now() - 1000 * 60 * 3)}
        isOwn={true}
        isRead={true}
      />
      <MessageBubble
        message="That's awesome! I'd love to hear more about it."
        timestamp={new Date(Date.now() - 1000 * 60 * 1)}
        isOwn={false}
        senderName="Alex"
        senderAvatar={avatar1}
      />
    </div>
  );
}
