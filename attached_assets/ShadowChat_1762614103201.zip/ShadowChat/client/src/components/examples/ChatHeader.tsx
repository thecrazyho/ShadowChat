import ChatHeader from '../ChatHeader';
import avatar1 from '@assets/generated_images/Neon_gradient_avatar_1_a8a998c7.png';
import groupIcon from '@assets/generated_images/Group_chat_icon_480eb873.png';

export default function ChatHeaderExample() {
  return (
    <div className="flex flex-col gap-4 bg-background">
      <ChatHeader
        name="Alex Chen"
        avatar={avatar1}
        status="online"
        userId="0042"
        onSearchClick={() => console.log('Search')}
        onCallClick={() => console.log('Call')}
        onVideoClick={() => console.log('Video')}
        onMenuClick={() => console.log('Menu')}
      />
      <ChatHeader
        name="Team Alpha"
        avatar={groupIcon}
        isGroup={true}
        memberCount={8}
        onSearchClick={() => console.log('Search')}
        onMenuClick={() => console.log('Menu')}
      />
    </div>
  );
}
