import { useState } from 'react';
import ConversationItem from '../ConversationItem';
import avatar1 from '@assets/generated_images/Neon_gradient_avatar_1_a8a998c7.png';
import avatar2 from '@assets/generated_images/Neon_gradient_avatar_2_646bcdde.png';
import avatar3 from '@assets/generated_images/Neon_gradient_avatar_3_3ab5493c.png';
import groupIcon from '@assets/generated_images/Group_chat_icon_480eb873.png';

export default function ConversationItemExample() {
  const [activeId, setActiveId] = useState("1");

  return (
    <div className="flex flex-col gap-2 p-4 bg-sidebar max-w-md">
      <ConversationItem
        id="1"
        name="Alex Chen"
        avatar={avatar1}
        lastMessage="Hey! How's the project going?"
        timestamp={new Date(Date.now() - 1000 * 60 * 5)}
        unreadCount={3}
        isActive={activeId === "1"}
        status="online"
        onClick={() => setActiveId("1")}
      />
      <ConversationItem
        id="2"
        name="Team Alpha"
        avatar={groupIcon}
        lastMessage="Meeting at 3pm tomorrow"
        timestamp={new Date(Date.now() - 1000 * 60 * 30)}
        unreadCount={12}
        isActive={activeId === "2"}
        isGroup={true}
        onClick={() => setActiveId("2")}
      />
      <ConversationItem
        id="3"
        name="Jordan Smith"
        avatar={avatar2}
        lastMessage="Thanks for the help!"
        timestamp={new Date(Date.now() - 1000 * 60 * 60 * 2)}
        isActive={activeId === "3"}
        status="away"
        onClick={() => setActiveId("3")}
      />
      <ConversationItem
        id="4"
        name="Sam Taylor"
        avatar={avatar3}
        lastMessage="See you later"
        timestamp={new Date(Date.now() - 1000 * 60 * 60 * 24)}
        isActive={activeId === "4"}
        status="offline"
        onClick={() => setActiveId("4")}
      />
    </div>
  );
}
