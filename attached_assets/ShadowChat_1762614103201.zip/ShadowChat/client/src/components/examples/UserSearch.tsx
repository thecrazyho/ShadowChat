import UserSearch from '../UserSearch';

export default function UserSearchExample() {
  return (
    <div className="h-screen bg-background max-w-md">
      <UserSearch
        onSelectUser={(user) => console.log('Selected:', user)}
        onClose={() => console.log('Close search')}
      />
    </div>
  );
}
