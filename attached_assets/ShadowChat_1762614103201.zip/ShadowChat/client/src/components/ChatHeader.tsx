import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { MoreVertical, Search, Phone, Video } from "lucide-react";
import OnlineStatus from "./OnlineStatus";

type Status = "online" | "away" | "busy" | "offline";

interface ChatHeaderProps {
  name: string;
  avatar?: string;
  status?: Status;
  isGroup?: boolean;
  memberCount?: number;
  userId?: string;
  onSearchClick?: () => void;
  onCallClick?: () => void;
  onVideoClick?: () => void;
  onMenuClick?: () => void;
}

export default function ChatHeader({
  name,
  avatar,
  status = "offline",
  isGroup = false,
  memberCount,
  userId,
  onSearchClick,
  onCallClick,
  onVideoClick,
  onMenuClick,
}: ChatHeaderProps) {
  return (
    <div className="flex items-center justify-between gap-4 px-4 py-3 border-b border-border bg-card">
      <div className="flex items-center gap-3 min-w-0">
        <div className="relative shrink-0">
          <Avatar className="w-10 h-10">
            <AvatarImage src={avatar} alt={name} />
            <AvatarFallback className="bg-muted">
              {name.charAt(0).toUpperCase()}
            </AvatarFallback>
          </Avatar>
          {!isGroup && <OnlineStatus status={status} className="absolute -bottom-0.5 -right-0.5" />}
        </div>

        <div className="min-w-0 flex-1">
          <h2 className="font-semibold text-base truncate" data-testid="text-chat-name">
            {name}
          </h2>
          <div className="flex items-center gap-2">
            {userId && (
              <Badge
                variant="secondary"
                className="font-mono text-xs px-2 py-0"
                data-testid="badge-user-id"
              >
                #{userId}
              </Badge>
            )}
            {isGroup && memberCount && (
              <span className="text-xs text-muted-foreground" data-testid="text-member-count">
                {memberCount} members
              </span>
            )}
            {!isGroup && (
              <span className="text-xs text-muted-foreground capitalize">
                {status}
              </span>
            )}
          </div>
        </div>
      </div>

      <div className="flex items-center gap-1 shrink-0">
        <Button
          size="icon"
          variant="ghost"
          data-testid="button-search"
          onClick={onSearchClick}
        >
          <Search className="h-5 w-5" />
        </Button>

        {!isGroup && (
          <>
            <Button
              size="icon"
              variant="ghost"
              data-testid="button-call"
              onClick={onCallClick}
            >
              <Phone className="h-5 w-5" />
            </Button>

            <Button
              size="icon"
              variant="ghost"
              data-testid="button-video"
              onClick={onVideoClick}
            >
              <Video className="h-5 w-5" />
            </Button>
          </>
        )}

        <Button
          size="icon"
          variant="ghost"
          data-testid="button-menu"
          onClick={onMenuClick}
        >
          <MoreVertical className="h-5 w-5" />
        </Button>
      </div>
    </div>
  );
}
