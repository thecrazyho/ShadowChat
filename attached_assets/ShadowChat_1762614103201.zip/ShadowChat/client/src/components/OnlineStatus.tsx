import { cn } from "@/lib/utils";

type Status = "online" | "away" | "busy" | "offline";

interface OnlineStatusProps {
  status: Status;
  className?: string;
  showLabel?: boolean;
}

export default function OnlineStatus({ status, className, showLabel = false }: OnlineStatusProps) {
  const statusColors = {
    online: "bg-green-500",
    away: "bg-yellow-500",
    busy: "bg-red-500",
    offline: "bg-muted-foreground",
  };

  const statusLabels = {
    online: "Online",
    away: "Away",
    busy: "Busy",
    offline: "Offline",
  };

  return (
    <div className={cn("flex items-center gap-1.5", className)}>
      <div className={cn("w-2.5 h-2.5 rounded-full", statusColors[status])} />
      {showLabel && <span className="text-xs text-muted-foreground">{statusLabels[status]}</span>}
    </div>
  );
}
