import { useState, useRef } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Users, Image as ImageIcon, Copy, Check } from "lucide-react";

interface GroupCreationModalProps {
  isOpen: boolean;
  onClose: () => void;
  onCreate?: (groupName: string, groupImage?: File) => void;
}

export default function GroupCreationModal({ isOpen, onClose, onCreate }: GroupCreationModalProps) {
  const [groupName, setGroupName] = useState("");
  const [groupImage, setGroupImage] = useState<File | null>(null);
  const [imagePreview, setImagePreview] = useState<string>("");
  const [inviteCode] = useState("GRP-" + Math.random().toString(36).substring(2, 8).toUpperCase());
  const [copied, setCopied] = useState(false);
  const imageInputRef = useRef<HTMLInputElement>(null);

  const handleImageChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      const file = e.target.files[0];
      setGroupImage(file);
      setImagePreview(URL.createObjectURL(file));
    }
  };

  const handleCreate = () => {
    console.log("Creating group:", groupName, groupImage?.name);
    onCreate?.(groupName, groupImage || undefined);
    setGroupName("");
    setGroupImage(null);
    setImagePreview("");
    onClose();
  };

  const handleCopyCode = () => {
    navigator.clipboard.writeText(inviteCode);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="sm:max-w-md">
        <DialogHeader>
          <DialogTitle>Create Group Chat</DialogTitle>
          <DialogDescription>
            Set up a new group and share the invite code with members
          </DialogDescription>
        </DialogHeader>

        <div className="space-y-4 pt-4">
          <div className="flex flex-col items-center gap-4">
            <Avatar className="w-24 h-24 cursor-pointer" onClick={() => imageInputRef.current?.click()}>
              <AvatarImage src={imagePreview} alt="Group" />
              <AvatarFallback className="bg-card">
                {groupName ? groupName.charAt(0).toUpperCase() : <Users className="w-8 h-8" />}
              </AvatarFallback>
            </Avatar>

            <input
              ref={imageInputRef}
              type="file"
              accept="image/*"
              className="hidden"
              onChange={handleImageChange}
            />

            <Button
              type="button"
              variant="outline"
              size="sm"
              data-testid="button-select-image"
              onClick={() => imageInputRef.current?.click()}
            >
              <ImageIcon className="w-4 h-4 mr-2" />
              Select Image
            </Button>
          </div>

          <div className="space-y-2">
            <Label htmlFor="groupName">Group Name</Label>
            <Input
              id="groupName"
              data-testid="input-group-name"
              type="text"
              placeholder="Enter group name"
              value={groupName}
              onChange={(e) => setGroupName(e.target.value)}
              required
            />
          </div>

          <div className="space-y-2">
            <Label>Invite Code</Label>
            <div className="flex gap-2">
              <Input
                data-testid="text-invite-code"
                type="text"
                value={inviteCode}
                readOnly
                className="font-mono"
              />
              <Button
                type="button"
                size="icon"
                variant="outline"
                data-testid="button-copy-code"
                onClick={handleCopyCode}
              >
                {copied ? <Check className="w-4 h-4" /> : <Copy className="w-4 h-4" />}
              </Button>
            </div>
          </div>

          <div className="flex gap-2 pt-4">
            <Button
              type="button"
              variant="outline"
              onClick={onClose}
              data-testid="button-cancel"
              className="flex-1"
            >
              Cancel
            </Button>
            <Button
              type="button"
              onClick={handleCreate}
              data-testid="button-create-group"
              disabled={!groupName.trim()}
              className="flex-1"
            >
              Create Group
            </Button>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}
