import { useState, useEffect } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import ConversationItem from "@/components/ConversationItem";
import ChatHeader from "@/components/ChatHeader";
import MessageBubble from "@/components/MessageBubble";
import ChatInput from "@/components/ChatInput";
import UserSearch from "@/components/UserSearch";
import GroupCreationModal from "@/components/GroupCreationModal";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Badge } from "@/components/ui/badge";
import { Search, Plus, Menu, LogOut, Users } from "lucide-react";
import { authApi, conversationApi, messageApi, userApi, uploadApi } from "@/lib/api";
import { getSocket } from "@/lib/socket";
import { queryClient } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import type { Conversation, Message } from "@/lib/api";

interface ChatPageProps {
  user: any;
  onLogout: () => void;
}

export default function ChatPage({ user, onLogout }: ChatPageProps) {
  const [activeConversationId, setActiveConversationId] = useState<number | null>(null);
  const [showUserSearch, setShowUserSearch] = useState(false);
  const [showGroupModal, setShowGroupModal] = useState(false);
  const [sidebarOpen, setSidebarOpen] = useState(true);
  const [searchQuery, setSearchQuery] = useState("");
  const [messages, setMessages] = useState<Message[]>([]);
  const { toast } = useToast();

  const { data: conversationsData, refetch: refetchConversations } = useQuery<{ conversations: Conversation[] }>({
    queryKey: ["/api/conversations"],
    refetchInterval: 5000,
  });

  const { data: messagesData } = useQuery({
    queryKey: ["/api/conversations", activeConversationId, "messages"],
    enabled: !!activeConversationId,
    queryFn: () => messageApi.getMessages(activeConversationId!),
  });

  useEffect(() => {
    if (messagesData?.messages) {
      setMessages(messagesData.messages);
    }
  }, [messagesData]);

  useEffect(() => {
    const socket = getSocket();

    if (activeConversationId) {
      socket.emit("conversation:join", activeConversationId);
    }

    socket.on(`conversation:${activeConversationId}:message`, (message: Message) => {
      setMessages((prev) => [...prev, message]);
      refetchConversations();
      
      if (message.senderId !== user.id) {
        messageApi.markAsRead(activeConversationId!).catch(console.error);
      }
    });

    socket.on("user:status", ({ userId, status }) => {
      queryClient.invalidateQueries({ queryKey: ["/api/conversations"] });
    });

    return () => {
      socket.off(`conversation:${activeConversationId}:message`);
      socket.off("user:status");
    };
  }, [activeConversationId, user.id, refetchConversations]);

  const createPrivateChatMutation = useMutation({
    mutationFn: (targetUserId: number) => conversationApi.createPrivate(targetUserId),
    onSuccess: (data) => {
      setActiveConversationId(data.conversation.id);
      setShowUserSearch(false);
      refetchConversations();
    },
    onError: (error: any) => {
      toast({
        title: "Error",
        description: error.message || "Failed to create conversation",
        variant: "destructive",
      });
    },
  });

  const createGroupMutation = useMutation({
    mutationFn: ({ name, inviteCode }: { name: string; inviteCode: string }) =>
      conversationApi.createGroup(name, inviteCode),
    onSuccess: (data) => {
      setActiveConversationId(data.conversation.id);
      setShowGroupModal(false);
      refetchConversations();
      toast({
        title: "Success",
        description: "Group created successfully",
      });
    },
    onError: (error: any) => {
      toast({
        title: "Error",
        description: error.message || "Failed to create group",
        variant: "destructive",
      });
    },
  });

  const handleLogout = async () => {
    try {
      await authApi.logout();
      onLogout();
    } catch (error) {
      console.error("Logout error:", error);
      onLogout();
    }
  };

  const handleSendMessage = async (content: string, files?: File[]) => {
    if (!activeConversationId) return;

    let fileUrl: string | undefined;
    let fileName: string | undefined;
    let fileType: string | undefined;

    if (files && files.length > 0) {
      try {
        const uploadResult = await uploadApi.uploadFile(files[0]);
        fileUrl = uploadResult.fileUrl;
        fileName = uploadResult.fileName;
        fileType = uploadResult.fileType;
      } catch (error) {
        toast({
          title: "Error",
          description: "File upload failed",
          variant: "destructive",
        });
        return;
      }
    }

    const socket = getSocket();
    socket.emit("message:send", {
      conversationId: activeConversationId,
      senderId: user.id,
      content,
      fileUrl,
      fileName,
      fileType,
      senderName: user.username,
      senderAvatar: user.avatar,
    });
  };

  const conversations = conversationsData?.conversations || [];
  const filteredConversations = conversations.filter((conv: Conversation) =>
    conv.name?.toLowerCase().includes(searchQuery.toLowerCase())
  );
  const activeConversation = conversations.find((c: Conversation) => c.id === activeConversationId);

  return (
    <div className="flex h-screen bg-background">
      <div className={`${sidebarOpen ? 'w-80' : 'w-0'} transition-all duration-200 flex-shrink-0 border-r border-border bg-sidebar overflow-hidden`}>
        <div className="flex flex-col h-full">
          <div className="p-4 border-b border-sidebar-border space-y-3">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-3">
                <Avatar className="w-10 h-10">
                  <AvatarImage src={user.avatar} alt={user.username} />
                  <AvatarFallback>{user.username.charAt(0).toUpperCase()}</AvatarFallback>
                </Avatar>
                <div>
                  <h3 className="font-semibold text-sm">{user.username}</h3>
                  <Badge variant="secondary" className="font-mono text-xs px-2 py-0">
                    #{user.displayId}
                  </Badge>
                </div>
              </div>
              <Button
                size="icon"
                variant="ghost"
                data-testid="button-logout"
                onClick={handleLogout}
              >
                <LogOut className="h-5 w-5" />
              </Button>
            </div>

            <div className="relative">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
              <Input
                data-testid="input-search-conversations"
                type="text"
                placeholder="Search conversations..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="pl-10"
              />
            </div>

            <div className="flex gap-2">
              <Button
                size="sm"
                variant="outline"
                data-testid="button-new-chat"
                onClick={() => setShowUserSearch(true)}
                className="flex-1"
              >
                <Plus className="h-4 w-4 mr-2" />
                New Chat
              </Button>
              <Button
                size="sm"
                variant="outline"
                data-testid="button-new-group"
                onClick={() => setShowGroupModal(true)}
                className="flex-1"
              >
                <Users className="h-4 w-4 mr-2" />
                New Group
              </Button>
            </div>
          </div>

          <div className="flex-1 overflow-y-auto p-2">
            {filteredConversations.map((conv: Conversation) => (
              <ConversationItem
                key={conv.id}
                id={String(conv.id)}
                name={conv.name || "Unknown"}
                avatar={conv.avatar}
                lastMessage={conv.lastMessage || "No messages yet"}
                timestamp={conv.lastMessageTime ? new Date(conv.lastMessageTime) : new Date()}
                unreadCount={conv.unreadCount}
                isActive={conv.id === activeConversationId}
                isGroup={conv.isGroup}
                status={conv.status as any}
                onClick={() => {
                  setActiveConversationId(conv.id);
                  if (conv.unreadCount && conv.unreadCount > 0) {
                    messageApi.markAsRead(conv.id).catch(console.error);
                  }
                }}
              />
            ))}
          </div>
        </div>
      </div>

      <div className="flex-1 flex flex-col min-w-0">
        {showUserSearch ? (
          <UserSearch
            onSelectUser={(selectedUser) => {
              createPrivateChatMutation.mutate(selectedUser.id);
            }}
            onClose={() => setShowUserSearch(false)}
          />
        ) : activeConversation ? (
          <>
            <div className="flex items-center gap-2 lg:hidden p-2 border-b border-border">
              <Button
                size="icon"
                variant="ghost"
                data-testid="button-toggle-sidebar"
                onClick={() => setSidebarOpen(!sidebarOpen)}
              >
                <Menu className="h-5 w-5" />
              </Button>
            </div>

            <ChatHeader
              name={activeConversation.name || "Unknown"}
              avatar={activeConversation.avatar}
              status={activeConversation.status as any}
              isGroup={activeConversation.isGroup}
              memberCount={activeConversation.memberCount}
              userId={activeConversation.userId}
              onSearchClick={() => console.log("Search messages")}
              onCallClick={() => console.log("Call")}
              onVideoClick={() => console.log("Video call")}
              onMenuClick={() => console.log("Menu")}
            />

            <div className="flex-1 overflow-y-auto p-4 space-y-4">
              {messages.map((msg) => (
                <MessageBubble
                  key={msg.id}
                  message={msg.content}
                  timestamp={new Date(msg.createdAt)}
                  isOwn={msg.senderId === user.id}
                  senderName={msg.senderName}
                  senderAvatar={msg.senderAvatar}
                  isRead={true}
                  fileUrl={msg.fileUrl}
                  fileName={msg.fileName}
                />
              ))}
            </div>

            <ChatInput onSendMessage={handleSendMessage} />
          </>
        ) : (
          <div className="flex-1 flex items-center justify-center text-muted-foreground">
            Select a conversation to start messaging
          </div>
        )}
      </div>

      <GroupCreationModal
        isOpen={showGroupModal}
        onClose={() => setShowGroupModal(false)}
        onCreate={(name) => {
          const inviteCode = "GRP-" + Math.random().toString(36).substring(2, 8).toUpperCase();
          createGroupMutation.mutate({ name, inviteCode });
        }}
      />
    </div>
  );
}
